function t = twiddlefactor(m,N)
 t = exp(-1*j*2*pi*m/N);
end